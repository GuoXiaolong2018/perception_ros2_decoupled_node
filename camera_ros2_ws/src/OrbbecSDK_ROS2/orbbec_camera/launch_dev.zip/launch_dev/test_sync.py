
import cv2
from orbbec_sync import SyncCameraInterface  
import time

def main():
    cam = SyncCameraInterface(spin_thread=True)
    try:
        while True:
            img1, img2 = cam.get_frame(timeout=2.0)
            if img1 is None:
                print("超时未收到同步帧")
                continue
            cv2.imshow('Camera 1', img1)
            cv2.imshow('Camera 2', img2)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('m') or key == ord('M'):
                timestamp = time.strftime("%Y%m%d_%H%M%S")
                cv2.imwrite(f"capture_cam1_{timestamp}.png", img1)
                cv2.imwrite(f"capture_cam2_{timestamp}.png", img2)
                print(f"已保存图像对 at {timestamp}")
            elif key == ord('q') or key == ord('Q'):
                print("用户退出")
                break
    finally:
        cv2.destroyAllWindows()
        cam.close()

if __name__ == "__main__":
    main()