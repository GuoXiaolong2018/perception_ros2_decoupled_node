#!/usr/bin/env python3
"""
提供 SyncCameraInterface 类，实例化后可调用 get_frame() 获取同步后的两个可见光图像。
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import message_filters
import numpy as np
import cv2
import threading
import time
from typing import Tuple, Optional


class SyncCameraInterface(Node):
    _ros_initialized = False
    _ros_initialized_by_us = False
    _instance_count = 0
    _instance_lock = threading.Lock()

    @classmethod
    def _ensure_ros_initialized(cls):
        """确保 rclpy 已被初始化，并记录是否由本类初始化"""
        with cls._instance_lock:
            if not cls._ros_initialized:
                try:
                    rclpy.init()
                    cls._ros_initialized_by_us = True
                except RuntimeError:
                    cls._ros_initialized_by_us = False
                cls._ros_initialized = True

    def __init__(self, spin_thread: bool = True, timeout_slop: float = 0.02):
        """
        初始化同步相机接口。
        :param spin_thread: 是否自动启动后台线程处理 ROS 消息
        :param timeout_slop: 时间同步容忍度（秒），默认 0.02 秒
        """
        self._ensure_ros_initialized()
        with self._instance_lock:
            self.__class__._instance_count += 1

        node_name = f'sync_camera_{id(self)}'
        super().__init__(node_name)

        self._timeout_slop = timeout_slop
        self._lock = threading.Lock()
        self._cond = threading.Condition(self._lock)
        self._latest_img_pair = (None, None)          # (img1, img2)
        self._new_frame_available = False

        sub_cam1 = message_filters.Subscriber(self, Image, '/camera_01/color/image_raw')
        sub_cam2 = message_filters.Subscriber(self, Image, '/camera_02/color/image_raw')

        self.sync = message_filters.ApproximateTimeSynchronizer(
            [sub_cam1, sub_cam2],
            queue_size=10,
            slop=self._timeout_slop,
            allow_headerless=False
        )
        self.sync.registerCallback(self._sync_callback)

        self.get_logger().info('同步相机模块节点已启动，等待图像...')

        self._running = False
        self._spin_thread = None
        if spin_thread:
            self.start()

    def _sync_callback(self, msg1: Image, msg2: Image):
        """同步回调：收到时间对齐的图像对"""
        try:
            img1 = self._ros_image_to_cv2(msg1)
            img2 = self._ros_image_to_cv2(msg2)
        except Exception as e:
            self.get_logger().error(f'图像转换失败: {e}')
            return

        with self._cond:
            self._latest_img_pair = (img1, img2)
            self._new_frame_available = True
            self._cond.notify_all()

    def _ros_image_to_cv2(self, msg: Image) -> np.ndarray:
        """将 ROS2 Image 消息转换为 OpenCV 图像（支持常见编码）"""
        height = msg.height
        width = msg.width
        encoding = msg.encoding
        data = np.frombuffer(msg.data, dtype=np.uint8)

        if encoding in ['mono8', '8UC1']:
            return data.reshape((height, width))
        elif encoding in ['bgr8', '8UC3']:
            return data.reshape((height, width, 3))
        elif encoding == 'rgb8':
            img = data.reshape((height, width, 3))
            return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        elif encoding in ['bgra8', '8UC4']:
            return data.reshape((height, width, 4))
        elif encoding == 'rgba8':
            img = data.reshape((height, width, 4))
            return cv2.cvtColor(img, cv2.COLOR_RGBA2BGRA)
        elif encoding in ['16UC1', 'mono16']:
            data16 = np.frombuffer(msg.data, dtype=np.uint16)
            return data16.reshape((height, width))
        else:
            raise ValueError(f'不支持的编码格式: {encoding}')

    def get_frame(self, timeout: Optional[float] = 2.0) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """
        获取最新同步的一对图像。

        阻塞直到新的同步帧到达，返回 (img1, img2)，均为 OpenCV 格式的 numpy 数组。
        如果设置了 timeout（秒），超时后仍未收到新帧则返回 (None, None)。

        参数:
            timeout: 可选，超时时间（秒），None 表示无限等待。

        返回:
            (img1, img2): 两个相机的图像，如果超时或失败则为 (None, None)。
        """
        with self._cond:
            if not self._new_frame_available:
                success = self._cond.wait(timeout=timeout)
                if not success:
                    return (None, None)

            img1, img2 = self._latest_img_pair
            self._new_frame_available = False
            return (img1, img2)

    def start(self):
        """启动后台 spin 线程"""
        if self._running:
            return
        self._running = True
        self._spin_thread = threading.Thread(target=self._spin, daemon=True)
        self._spin_thread.start()
        self.get_logger().info("后台 spin 线程已启动")

    def stop(self):
        """停止后台 spin 线程"""
        self._running = False
        if self._spin_thread is not None:
            self._spin_thread.join(timeout=2.0)
            self._spin_thread = None
        self.get_logger().info("后台 spin 线程已停止")

    def _spin(self):
        """后台 spin 循环 """
        while self._running and rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.1)
        self.get_logger().info("spin 线程退出")

    def destroy_node(self):
        """销毁节点（重写父类方法，确保先停止线程）"""
        self.stop()
        super().destroy_node()

    def close(self):
        """释放资源，并递减实例计数；若为最后一个实例且由本类初始化 ROS，则关闭 ROS"""
        self.destroy_node()
        with self._instance_lock:
            self.__class__._instance_count -= 1
            if self.__class__._instance_count == 0 and self.__class__._ros_initialized_by_us:
                if rclpy.ok():
                    rclpy.shutdown()
                    self.get_logger().info("ROS 已关闭")