from ros2_orbbec_interface import OrbbecInterface
import cv2

def main():
    # 创建相机接口实例（自动初始化ROS并启动后台线程）
    cam = OrbbecInterface(spin_thread=True)
    intrinsics = cam.get_camera_intrinsics
    print("intrinsics:", intrinsics)

    try:
        while True:
            color, depth = cam.get_frame()

            if color is not None:
                cv2.imshow('Color', color)
            if depth is not None:
                # 深度图可视化
                depth_vis = cv2.normalize(depth, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                cv2.imshow('Depth', depth_vis)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
    finally:
        cv2.destroyAllWindows()
        cam.close()   # 

if __name__ == '__main__':
    main()