import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
import numpy as np
import cv2
import threading
import time
from typing import Tuple, Dict, Optional
import open3d as o3d

class OBCameraIntrinsic:
    def __init__(self, fx, fy, cx, cy, width, height):
        self.fx = fx
        self.fy = fy
        self.cx = cx
        self.cy = cy
        self.width = width
        self.height = height

    def __repr__(self):
        return f"<OBCameraIntrinsic fx={self.fx:.6f} fy={self.fy:.6f} cx={self.cx:.6f} cy={self.cy:.6f} width={self.width} height={self.height}>"

class OBCameraDistortion:
    def __init__(self, k1=0.0, k2=0.0, k3=0.0, k4=0.0, k5=0.0, k6=0.0, p1=0.0, p2=0.0):
        self.k1 = k1
        self.k2 = k2
        self.k3 = k3
        self.k4 = k4
        self.k5 = k5
        self.k6 = k6
        self.p1 = p1
        self.p2 = p2

    def __repr__(self):
        return f"<OBCameraDistortion k1={self.k1:.6f} k2={self.k2:.6f} k3={self.k3:.6f} k4={self.k4:.6f} k5={self.k5:.6f} k6={self.k6:.6f} p1={self.p1:.6f} p2={self.p2:.6f}>"


class OrbbecInterface(Node):
    # 类变量，用于跟踪 ROS 初始化状态
    _ros_initialized = False
    _ros_initialized_by_us = False

    @classmethod
    def _ensure_ros_initialized(cls):
        """确保 rclpy 已经被初始化（只尝试一次）"""
        if not cls._ros_initialized:
            try:
                rclpy.init()
                cls._ros_initialized_by_us = True
            except RuntimeError:
                # 已经由其他代码初始化
                cls._ros_initialized_by_us = False
            cls._ros_initialized = True

    def __init__(self, spin_thread: bool = True):
        """
        初始化相机接口。
        :param spin_thread: 是否自动启动后台线程处理 ROS 消息
        """
        # 确保 ROS 已初始化
        self._ensure_ros_initialized()

        super().__init__('camera_interface')
        
        self._lock = threading.Lock()
        self._latest_color: Optional[Image] = None
        self._latest_depth: Optional[Image] = None
        self._color_camera_info: Optional[CameraInfo] = None
        self._depth_camera_info: Optional[CameraInfo] = None
        
        self._color_info_event = threading.Event()
        self._depth_info_event = threading.Event()
        
        # 订阅器
        self.color_sub = self.create_subscription(
            Image,
            '/camera_01/color/image_raw',
            self.color_callback,
            1
        )
        self.depth_sub = self.create_subscription(
            Image,
            '/camera_01/depth/image_raw',
            self.depth_callback,
            1
        )
        self.color_info_sub = self.create_subscription(
            CameraInfo,
            '/camera_01/color/camera_info',
            self.color_info_callback,
            1
        )
        self.depth_info_sub = self.create_subscription(
            CameraInfo,
            '/camera_01/depth/camera_info',
            self.depth_info_callback,
            1
        )
        
        self.get_logger().info('Camera interface initialized, waiting for topics...')
        
        self._running = False
        self._spin_thread = None
        if spin_thread:
            self.start()
    
    def color_callback(self, msg: Image):
        with self._lock:
            self._latest_color = msg
    
    def depth_callback(self, msg: Image):
        with self._lock:
            self._latest_depth = msg
    
    def color_info_callback(self, msg: CameraInfo):
        with self._lock:
            self._color_camera_info = msg
        self._color_info_event.set()
    
    def depth_info_callback(self, msg: CameraInfo):
        with self._lock:
            self._depth_camera_info = msg
        self._depth_info_event.set()
    
    def ros_image_to_cv2(self, msg: Image) -> np.ndarray:
        """将 ROS2 Image 消息转换为 OpenCV 图像（支持常见编码）"""
        height = msg.height
        width = msg.width
        encoding = msg.encoding
        data = np.frombuffer(msg.data, dtype=np.uint8)

        if encoding in ['mono8', '8UC1']:
            return data.reshape((height, width))
        elif encoding in ['bgr8', '8UC3']:
            return data.reshape((height, width, 3))
        elif encoding == 'rgb8':
            img = data.reshape((height, width, 3))
            return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        elif encoding in ['bgra8', '8UC4']:
            return data.reshape((height, width, 4))
        elif encoding == 'rgba8':
            img = data.reshape((height, width, 4))
            return cv2.cvtColor(img, cv2.COLOR_RGBA2BGRA)
        elif encoding in ['16UC1', 'mono16']:
            data16 = np.frombuffer(msg.data, dtype=np.uint16)
            return data16.reshape((height, width))
        elif encoding == '32FC1':
            data32 = np.frombuffer(msg.data, dtype=np.float32)
            return data32.reshape((height, width))
        else:
            raise ValueError(f'不支持的编码格式: {encoding}')

    def get_frame(self) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
        """
        获取最新的RGB图像（BGR格式）和深度图像（以米为单位的 float32 数组，无效值为0）。
        如果没有收到任何图像，对应项返回None。
        """
        with self._lock:
            color_msg = self._latest_color
            depth_msg = self._latest_depth
        
        color_img = None
        depth_img = None
        
        if color_msg is not None:
            try:
                color_img = self.ros_image_to_cv2(color_msg)
            except Exception as e:
                self.get_logger().error(f'Failed to convert color image: {e}')
        
        if depth_msg is not None:
            try:
                raw_depth = self.ros_image_to_cv2(depth_msg)
                
                if depth_msg.encoding == '16UC1':
                    depth_img = raw_depth.astype(np.float32) * 0.001
                    # 过滤无效值：通常0表示无效，也可设置合理范围（如0.1~10米）
                    depth_img = np.where((depth_img > 0.1) & (depth_img < 10.0), depth_img, 0.0)
                elif depth_msg.encoding == '32FC1':
                    depth_img = raw_depth.copy()
                    depth_img = np.where((depth_img > 0.1) & (depth_img < 10.0), depth_img, 0.0)
                else:
                    self.get_logger().warn(f'Unexpected depth encoding: {depth_msg.encoding}, returning raw values.')
                    depth_img = raw_depth  # 保持原样
            except Exception as e:
                self.get_logger().error(f'Failed to process depth image: {e}')
        
        return color_img, depth_img

    @property
    def get_camera_intrinsics(self) -> Dict[str, Optional[object]]:
        """
        如果尚未收到对应信息，对应项返回 None。
        首次调用时，如果彩色内参未收到，将阻塞等待最多 1 秒。
        """
        if self._color_camera_info is None:
            self.get_logger().info("Waiting for color camera info...")
            if not self._color_info_event.wait(timeout=1.0):
                self.get_logger().error("Timeout waiting for color camera info.")
        if self._depth_camera_info is None:
            self.get_logger().info("Waiting for depth camera info...")
            self._depth_info_event.wait(timeout=1.0) 

        with self._lock:
            color_info = self._color_camera_info
            depth_info = self._depth_camera_info

        def build_intrinsics(info: Optional[CameraInfo]) -> Optional[OBCameraIntrinsic]:
            if info is None:
                return None
            # 从 CameraInfo.k 中提取 fx, fy, cx, cy
            # k 是行优先的9元素数组: [fx, 0, cx, 0, fy, cy, 0, 0, 1]
            k = info.k
            fx = k[0]
            fy = k[4]
            cx = k[2]
            cy = k[5]
            return OBCameraIntrinsic(fx, fy, cx, cy, info.width, info.height)

        def build_distortion(info: Optional[CameraInfo]) -> Optional[OBCameraDistortion]:
            if info is None:
                return None
            d = info.d  # 畸变系数数组
            # 根据常见模型 plumb_bob 映射为 8 参数 (k1,k2,k3,k4,k5,k6,p1,p2)
            # 默认所有为0
            dist = OBCameraDistortion()
            if len(d) >= 5:
                # plumb_bob: [k1, k2, p1, p2, k3]
                dist.k1 = d[0]
                dist.k2 = d[1]
                dist.p1 = d[2] if len(d) > 2 else 0.0
                dist.p2 = d[3] if len(d) > 3 else 0.0
                dist.k3 = d[4] if len(d) > 4 else 0.0
            # 其他参数保持0
            return dist

        return {
            'depth_intrinsics': build_intrinsics(depth_info),
            'depth_distortion': build_distortion(depth_info),
            'color_intrinsics': build_intrinsics(color_info),
            'color_distortion': build_distortion(color_info)
        }
    
    def wait_for_camera_info(self, timeout: float = 1.0, wait_depth: bool = False) -> bool:
        """
        阻塞直到收到彩色相机内参（可选深度内参）。
        :param timeout: 超时时间（秒）
        :param wait_depth: 是否同时等待深度内参
        :return: 是否在超时前收到所需内参
        """
        if wait_depth:
            start = time.time()
            while time.time() - start < timeout:
                if self._color_info_event.is_set() and self._depth_info_event.is_set():
                    return True
                time.sleep(0.05)
            return False
        else:
            return self._color_info_event.wait(timeout)
    
    def start(self):
        """启动后台spin线程"""
        if self._running:
            return
        self._running = True
        self._spin_thread = threading.Thread(target=self._spin, daemon=True)
        self._spin_thread.start()
        self.get_logger().info("Background spin thread started")
    
    def stop(self):
        """停止后台spin线程"""
        self._running = False
        if self._spin_thread is not None:
            self._spin_thread.join(timeout=2.0)
            self._spin_thread = None
        self.get_logger().info("Background spin thread stopped")
    
    def _spin(self):
        while self._running and rclpy.ok():
            rclpy.spin_once(self, timeout_sec=0.1)
        self.get_logger().info("Spin thread exiting")
    
    def destroy_node(self):
        self.stop()
        super().destroy_node()
    
    def close(self):
        """释放资源并关闭ROS（如果由本类初始化）"""
        self.destroy_node()
        if self._ros_initialized_by_us:
            rclpy.shutdown()

def rgbd2pcd(rgb, depth, depth_intrinsics_dict):
    """
    将RGB和深度图像转换为点云
    参数:
        rgb: np.ndarray, HWC, 8位uint8, RGB彩色
        depth: np.ndarray, HW, 16位uint16, 单位为毫米(mm)或者float, 单位为米
        depth_intrinsics_dict: dict, 包含fx, fy, cx, cy, width, height
    返回:
        o3d.geometry.PointCloud 对象
    """
	    # 如果深度是uint16（mm），转为米
    if depth.dtype == np.uint16:
        depth_o3d = o3d.geometry.Image(depth.astype(np.float32) / 1000.0)
    elif np.issubdtype(depth.dtype, np.floating):
        depth_o3d = o3d.geometry.Image(depth.astype(np.float32))
    else:
        raise ValueError("Unsupported depth dtype")

    color_o3d = o3d.geometry.Image(rgb)
    rgbd_image = o3d.geometry.RGBDImage.create_from_color_and_depth(
        color_o3d, depth_o3d,
        convert_rgb_to_intensity=False,
        depth_scale=1.0,  # 因为已转到米
        depth_trunc=10.0  # 可设置最大深度
    )

    # 构造内参 ：对齐后使用彩色相机内参
    intrinsic = o3d.camera.PinholeCameraIntrinsic(
        depth_intrinsics_dict['width'],
        depth_intrinsics_dict['height'],
        depth_intrinsics_dict['fx'],
        depth_intrinsics_dict['fy'],
        depth_intrinsics_dict['cx'],
        depth_intrinsics_dict['cy']
    )

    # 生成点云
    pcd = o3d.geometry.PointCloud.create_from_rgbd_image(
        rgbd_image, intrinsic
    )

    return pcd

if __name__ == '__main__':
    cam = OrbbecInterface(spin_thread=True)
    try:
        import time
        # 等待彩色内参到达（最多1秒）
        # if cam.wait_for_camera_info(timeout=1.0, wait_depth=False):
        #     ins = cam.get_camera_intrinsics
        #     print("Camera intrinsics:", ins)
        # else:
        #     print("Failed to receive camera info within timeout.")
        # color_intrinsics = ins['color_intrinsics']
        # color_intrinsics_dict = {
        #     'fx': float(color_intrinsics.fx),
        #     'fy': float(color_intrinsics.fy),
        #     'cx': float(color_intrinsics.cx),
        #     'cy': float(color_intrinsics.cy),
        #     'width': color_intrinsics.width,
        #     'height': color_intrinsics.height
        # }

        # print("Color camera intrinsics (dict):", color_intrinsics_dict)
        
        # while True:
        #     for i in range(2):
        #         color_frame, depth_frame = cam.get_frame()


        #     intrinsics = cam.get_camera_intrinsics
        #     color_intrinsics = intrinsics['color_intrinsics']
        #     color_intrinsics_dict = {
        #         'fx': color_intrinsics.fx,
        #         'fy': color_intrinsics.fy,
        #         'cx': color_intrinsics.cx,
        #         'cy': color_intrinsics.cy,
        #         'width': color_intrinsics.width,
        #         'height': color_intrinsics.height
        #     }

        #     # 使用对齐后的RGB和深度图生成点云
        #     pcd_from_rgbd = rgbd2pcd(color_frame, depth_frame, color_intrinsics_dict)

        #     # 可视化点云
        #     o3d.visualization.draw_geometries([pcd_from_rgbd])

        while rclpy.ok():
            color, depth = cam.get_frame()
            if color is not None:
                cv2.imshow('Color', color)
            if depth is not None:
                # 深度图可视化（归一化到0-255）
                depth_vis = cv2.normalize(depth, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                cv2.imshow('Depth', depth_vis)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            time.sleep(0.03)
    finally:
        # cv2.destroyAllWindows()
        cam.close()