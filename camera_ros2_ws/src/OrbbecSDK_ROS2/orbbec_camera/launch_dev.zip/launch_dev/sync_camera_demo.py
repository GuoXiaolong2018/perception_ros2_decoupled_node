# #!/usr/bin/env python3
# import rclpy
# from rclpy.node import Node
# from sensor_msgs.msg import Image
# import numpy as np
# import cv2
# import time  # 新增导入

# class ImageSubscriber(Node):
#     def __init__(self):
#         super().__init__('image_subscriber')
#         self.subscription = self.create_subscription(
#             Image,
#             '/camera_01/color/image_raw',
#             self.listener_callback,
#             10)
#         self.subscription
#         # 新增：记录上次处理的时间
#         self.last_process_time = time.time()
#         # 设置处理间隔（秒），例如 0.033 秒对应 30 FPS
#         self.process_interval = 0.033
#         self.get_logger().info('图像订阅节点已启动，等待数据...')

#     def listener_callback(self, msg):
#         # 时间节流：如果距离上次处理不足间隔时间，则直接丢弃当前帧
#         now = time.time()
#         if now - self.last_process_time < self.process_interval:
#             return
#         self.last_process_time = now

#         try:
#             # 转换图像
#             cv_image = self.ros_image_to_cv2(msg)
#         except Exception as e:
#             self.get_logger().error(f'图像转换失败: {e}')
#             return

#         # 显示图像
#         cv2.imshow('Camera 01 Color Image', cv_image)
#         cv2.waitKey(1)

#     def ros_image_to_cv2(self, msg):
#         """将 ROS2 Image 消息转换为 OpenCV 图像"""
#         height = msg.height
#         width = msg.width
#         encoding = msg.encoding
#         data = np.frombuffer(msg.data, dtype=np.uint8)

#         if encoding in ['mono8', '8UC1']:
#             return data.reshape((height, width))
#         elif encoding in ['bgr8', '8UC3']:
#             return data.reshape((height, width, 3))
#         elif encoding == 'rgb8':
#             img = data.reshape((height, width, 3))
#             return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
#         elif encoding in ['bgra8', '8UC4']:
#             return data.reshape((height, width, 4))
#         elif encoding == 'rgba8':
#             img = data.reshape((height, width, 4))
#             return cv2.cvtColor(img, cv2.COLOR_RGBA2BGRA)
#         elif encoding in ['16UC1', 'mono16']:
#             data16 = np.frombuffer(msg.data, dtype=np.uint16)
#             return data16.reshape((height, width))
#         else:
#             raise ValueError(f'Unsupported encoding: {encoding}')

# def main(args=None):
#     rclpy.init(args=args)
#     node = ImageSubscriber()

#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         node.get_logger().info('用户中断，正在关闭...')
#     finally:
#         node.destroy_node()
#         rclpy.shutdown()
#         cv2.destroyAllWindows()

# if __name__ == '__main__':
#     main()













# #!/usr/bin/env python3
# import rclpy
# from rclpy.node import Node
# from sensor_msgs.msg import Image
# import numpy as np
# import cv2
# import time

# class MultiCameraSubscriber(Node):
#     def __init__(self):
#         super().__init__('multi_camera_subscriber')

#         # 处理间隔（秒），0.033 ≈ 30 FPS
#         self.process_interval = 0.033
#         # 记录每个相机的上次处理时间
#         self.last_process_time = {
#             'cam1': time.time(),
#             'cam2': time.time()
#         }
#         # 存储每个相机的最新图像
#         self.latest_img = {
#             'cam1': None,
#             'cam2': None
#         }

#         # 创建两个订阅，分别绑定到不同相机 ID
#         self.sub1 = self.create_subscription(
#             Image,
#             '/camera_01/color/image_raw',
#             lambda msg: self.listener_callback(msg, 'cam1'),
#             10
#         )
#         self.sub2 = self.create_subscription(
#             Image,
#             '/camera_02/color/image_raw',
#             lambda msg: self.listener_callback(msg, 'cam2'),
#             10
#         )

#         self.get_logger().info('多相机订阅节点已启动，按 M 键拍照')

#     def listener_callback(self, msg, cam_id):
#         # 时间节流：每个相机独立控制处理频率
#         now = time.time()
#         if now - self.last_process_time[cam_id] < self.process_interval:
#             return
#         self.last_process_time[cam_id] = now

#         try:
#             # 转换 ROS 图像为 OpenCV 格式
#             cv_image = self.ros_image_to_cv2(msg)
#         except Exception as e:
#             self.get_logger().error(f'[{cam_id}] 图像转换失败: {e}')
#             return

#         # 更新最新图像
#         self.latest_img[cam_id] = cv_image

#         # 显示图像窗口
#         window_name = f'Camera {cam_id}'
#         cv2.imshow(window_name, cv_image)

#         # 检测按键（影响所有窗口）
#         key = cv2.waitKey(1) & 0xFF
#         if key == ord('m') or key == ord('M'):
#             self.save_images()

#     def ros_image_to_cv2(self, msg):
#         """将 ROS2 Image 消息转换为 OpenCV 图像（支持常见编码）"""
#         height = msg.height
#         width = msg.width
#         encoding = msg.encoding
#         data = np.frombuffer(msg.data, dtype=np.uint8)

#         if encoding in ['mono8', '8UC1']:
#             return data.reshape((height, width))
#         elif encoding in ['bgr8', '8UC3']:
#             return data.reshape((height, width, 3))
#         elif encoding == 'rgb8':
#             img = data.reshape((height, width, 3))
#             return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
#         elif encoding in ['bgra8', '8UC4']:
#             return data.reshape((height, width, 4))
#         elif encoding == 'rgba8':
#             img = data.reshape((height, width, 4))
#             return cv2.cvtColor(img, cv2.COLOR_RGBA2BGRA)
#         elif encoding in ['16UC1', 'mono16']:
#             data16 = np.frombuffer(msg.data, dtype=np.uint16)
#             return data16.reshape((height, width))
#         else:
#             raise ValueError(f'不支持的编码格式: {encoding}')

#     def save_images(self):
#         """保存两个相机的最新图像"""
#         timestamp = time.strftime("%Y%m%d_%H%M%S")
#         for cam_id, img in self.latest_img.items():
#             if img is not None:
#                 filename = f"capture_{cam_id}_{timestamp}.png"
#                 cv2.imwrite(filename, img)
#                 self.get_logger().info(f'已保存: {filename}')
#             else:
#                 self.get_logger().warn(f'{cam_id} 尚无图像，未保存')

# def main(args=None):
#     rclpy.init(args=args)
#     node = MultiCameraSubscriber()

#     try:
#         rclpy.spin(node)
#     except KeyboardInterrupt:
#         node.get_logger().info('用户中断，正在关闭...')
#     finally:
#         node.destroy_node()
#         rclpy.shutdown()
#         cv2.destroyAllWindows()

# if __name__ == '__main__':
#     main()












#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import message_filters
import numpy as np
import cv2
import time

class SyncCameraSubscriber(Node):
    def __init__(self):
        super().__init__('sync_camera_subscriber')

        # 创建两个独立的订阅器
        sub_cam1 = message_filters.Subscriber(self, Image, '/camera_01/color/image_raw')
        sub_cam2 = message_filters.Subscriber(self, Image, '/camera_02/color/image_raw')

        # 设置同步器
        # ApproximateTimeSynchronizer 允许一定的时间偏移（slop 参数，单位秒）
        # 队列大小设为 10，时间容忍度设为 0.02 秒（20 毫秒）
        self.sync = message_filters.ApproximateTimeSynchronizer(
            [sub_cam1, sub_cam2],
            queue_size=10,
            slop=0.02,
            allow_headerless=False
        )
        self.sync.registerCallback(self.sync_callback)

        # 用于存储最新同步图像
        self.latest_img = {'cam1': None, 'cam2': None}
        # 可选：控制显示帧率（例如每秒 30 帧）
        self.process_interval = 0.033   # 30 FPS
        self.last_display_time = time.time()

        self.get_logger().info('同步订阅节点已启动，按 M 键拍照')

    def sync_callback(self, msg1, msg2):
        """
        同步回调：两个图像时间戳相近时被调用
        """
        try:
            # 转换 ROS 图像为 OpenCV 格式
            img1 = self.ros_image_to_cv2(msg1)
            img2 = self.ros_image_to_cv2(msg2)
        except Exception as e:
            self.get_logger().error(f'图像转换失败: {e}')
            return

        # 更新最新图像
        self.latest_img['cam1'] = img1
        self.latest_img['cam2'] = img2

        # 控制显示频率（可选，若不需要可移除）
        now = time.time()
        if now - self.last_display_time >= self.process_interval:
            self.last_display_time = now
            # 显示图像
            cv2.imshow('Camera 01 (synced)', img1)
            cv2.imshow('Camera 02 (synced)', img2)

        # 检测按键（所有窗口共用）
        key = cv2.waitKey(1) & 0xFF
        if key == ord('m') or key == ord('M'):
            self.save_images()

    def ros_image_to_cv2(self, msg):
        """将 ROS2 Image 消息转换为 OpenCV 图像（支持常见编码）"""
        height = msg.height
        width = msg.width
        encoding = msg.encoding
        data = np.frombuffer(msg.data, dtype=np.uint8)

        if encoding in ['mono8', '8UC1']:
            return data.reshape((height, width))
        elif encoding in ['bgr8', '8UC3']:
            return data.reshape((height, width, 3))
        elif encoding == 'rgb8':
            img = data.reshape((height, width, 3))
            return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        elif encoding in ['bgra8', '8UC4']:
            return data.reshape((height, width, 4))
        elif encoding == 'rgba8':
            img = data.reshape((height, width, 4))
            return cv2.cvtColor(img, cv2.COLOR_RGBA2BGRA)
        elif encoding in ['16UC1', 'mono16']:
            data16 = np.frombuffer(msg.data, dtype=np.uint16)
            return data16.reshape((height, width))
        else:
            raise ValueError(f'不支持的编码格式: {encoding}')

    def save_images(self):
        """保存两个相机的最新同步图像"""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        for cam_id, img in self.latest_img.items():
            if img is not None:
                filename = f"sync_{cam_id}_{timestamp}.png"
                cv2.imwrite(filename, img)
                self.get_logger().info(f'已保存: {filename}')
            else:
                self.get_logger().warn(f'{cam_id} 尚无图像，未保存')

def main(args=None):
    rclpy.init(args=args)
    node = SyncCameraSubscriber()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('用户中断，正在关闭...')
    finally:
        node.destroy_node()
        rclpy.shutdown()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    main()